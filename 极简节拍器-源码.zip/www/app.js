'use strict';

/* ================= 配置 ================= */
const PRESETS = [
  { name: '慢板', bpm: 60 },
  { name: '行板', bpm: 80 },
  { name: '中板', bpm: 100 },
  { name: '快板', bpm: 140 },
  { name: '急板', bpm: 180 },
];

const SIGNATURES = [
  { label: '2/4', beats: 2 },
  { label: '3/4', beats: 3 },
  { label: '4/4', beats: 4 },
  { label: '6/8', beats: 6 },
];

const LOOKAHEAD = 100;   // 每次调度提前的毫秒数
const SCHED_INTERVAL = 25; // 调度器轮询间隔
const TICK_BASE_MS = 60;   // 毫秒转秒系数

/* ================= 状态 ================= */
let state = {
  bpm: 120,
  signature: 4, // 每小节拍数
  playing: false,
  currentBeat: -1,
  nextNoteTime: 0,
  scheduleTimer: null,
  visualTimer: null,
};

const els = {
  presets: document.getElementById('presets'),
  bpmNumber: document.getElementById('bpmNumber'),
  beats: document.getElementById('beats'),
  slider: document.getElementById('slider'),
  btnMinus: document.getElementById('btnMinus'),
  btnPlus: document.getElementById('btnPlus'),
  timeSigs: document.getElementById('timeSigs'),
  playBtn: document.getElementById('playBtn'),
  playIcon: document.getElementById('playIcon'),
};

/* ================= Web Audio ================= */
let audioCtx = null;
function ensureAudio() {
  if (!audioCtx) {
    const AC = window.AudioContext || window.webkitAudioContext;
    audioCtx = new AC();
  }
  if (audioCtx.state === 'suspended') audioCtx.resume();
  return audioCtx;
}

function scheduleTick(time, isAccent) {
  const ctx = audioCtx;
  const osc = ctx.createOscillator();
  const gain = ctx.createGain();

  osc.type = 'sine';
  osc.frequency.value = isAccent ? 1000 : 600;

  const attack = 0.005;
  const decay = isAccent ? 0.08 : 0.06;
  const peak = isAccent ? 0.8 : 0.5;

  gain.gain.setValueAtTime(0, time);
  gain.gain.linearRampToValueAtTime(peak, time + attack);
  gain.gain.exponentialRampToValueAtTime(0.0001, time + decay);

  osc.connect(gain);
  gain.connect(ctx.destination);
  osc.start(time);
  osc.stop(time + decay + 0.02);
}

/* ================= 调度器（Lookahead） ================= */
function scheduler() {
  while (state.nextNoteTime < audioCtx.currentTime + LOOKAHEAD / 1000) {
    const secondsPerBeat = TICK_BASE_MS / state.bpm;
    const beatInBar = state.currentBeat;
    const isAccent = beatInBar === 0;
    scheduleTick(state.nextNoteTime, isAccent);

    state.nextNoteTime += secondsPerBeat;
    state.currentBeat = (state.currentBeat + 1) % state.signature;
  }
}

function startMetronome() {
  const ctx = ensureAudio();
  state.playing = true;
  state.currentBeat = 0;
  state.nextNoteTime = ctx.currentTime + 0.05;

  els.playBtn.classList.add('playing');
  els.playBtn.setAttribute('aria-label', '停止');

  state.scheduleTimer = setInterval(scheduler, SCHED_INTERVAL);

  // 视觉：requestAnimationFrame 跟音频时钟对齐
  let last = 0;
  const beatLen = TICK_BASE_MS / state.bpm / 1000;
  const step = () => {
    if (!state.playing) return;
    const elapsed = audioCtx.currentTime - (state.nextNoteTime - beatLen * state.signature);
    const beatPos = Math.floor(elapsed / beatLen) % state.signature;
    updateBeats(beatPos);
    // BPM 数字随重拍轻微变色
    els.bpmNumber.classList.toggle('hit', beatPos === 0);
    requestAnimationFrame(step);
  };
  requestAnimationFrame(step);
}

function stopMetronome() {
  state.playing = false;
  clearInterval(state.scheduleTimer);
  els.playBtn.classList.remove('playing');
  els.playBtn.setAttribute('aria-label', '播放');
  els.bpmNumber.classList.remove('hit');
  updateBeats(-1);
}

/* ================= 视觉：圆点 ================= */
function renderBeats() {
  els.beats.innerHTML = '';
  for (let i = 0; i < state.signature; i++) {
    const dot = document.createElement('div');
    dot.className = 'beat-dot' + (i === 0 ? ' accent' : '');
    dot.dataset.index = i;
    els.beats.appendChild(dot);
  }
}
function updateBeats(activeIndex) {
  const dots = els.beats.children;
  for (let i = 0; i < dots.length; i++) {
    dots[i].classList.toggle('current', i === activeIndex);
  }
}

/* ================= 渲染 UI ================= */
function renderPresets() {
  PRESETS.forEach(p => {
    const btn = document.createElement('button');
    btn.className = 'preset-btn';
    btn.textContent = p.name;
    btn.addEventListener('click', () => {
      state.bpm = p.bpm;
      els.slider.value = p.bpm;
      updateBpm();
      setActivePreset(btn);
    });
    els.presets.appendChild(btn);
  });
}
function setActivePreset(activeBtn) {
  [...els.presets.children].forEach(b => b.classList.remove('active'));
  activeBtn.classList.add('active');
}

function renderSignatures() {
  SIGNATURES.forEach((s, idx) => {
    const btn = document.createElement('button');
    btn.className = 'sig-btn' + (idx === 0 ? ' active' : '');
    btn.textContent = s.label;
    btn.addEventListener('click', () => {
      state.signature = s.beats;
      [...els.timeSigs.children].forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      renderBeats();
      updateBeats(-1);
    });
    els.timeSigs.appendChild(btn);
  });
}

function updateBpm() {
  els.bpmNumber.textContent = state.bpm;
}

/* ================= 事件绑定 ================= */
els.slider.addEventListener('input', () => {
  state.bpm = Number(els.slider.value);
  updateBpm();
  [...els.presets.children].forEach(b => b.classList.remove('active'));
});
els.btnMinus.addEventListener('click', () => {
  state.bpm = Math.max(30, state.bpm - 1);
  els.slider.value = state.bpm;
  updateBpm();
  [...els.presets.children].forEach(b => b.classList.remove('active'));
});
els.btnPlus.addEventListener('click', () => {
  state.bpm = Math.min(240, state.bpm + 1);
  els.slider.value = state.bpm;
  updateBpm();
  [...els.presets.children].forEach(b => b.classList.remove('active'));
});

els.playBtn.addEventListener('click', () => {
  if (state.playing) stopMetronome();
  else startMetronome();
});

/* ================= 初始化 ================= */
renderPresets();
renderSignatures();
renderBeats();
updateBpm();
